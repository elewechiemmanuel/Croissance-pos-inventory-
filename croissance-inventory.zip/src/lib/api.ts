export async function apiCall(action: string, payload: any = {}) {
  try {
    let currentUser: any = null;
    try {
      const stored = localStorage.getItem("croissance_user");
      if (stored) {
        currentUser = JSON.parse(stored);
      }
    } catch (e) {
      // ignore
    }

    const payloadWithActor = {
      ...payload,
      _actor: payload._actor || (currentUser ? {
        id: currentUser.id,
        fullName: currentUser.fullName,
        email: currentUser.email,
        role: currentUser.role,
        station: currentUser.currentStation || (currentUser.role === "admin" ? "Admin Office" : "Station POS Terminal")
      } : undefined)
    };

    const response = await fetch("/api/sheets", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ action, payload: payloadWithActor }),
    });
    
    const result = await response.json();
    if (!result.success) {
      throw new Error(result.message || "API error");
    }
    return result.data;
  } catch (error: any) {
    console.error("API Call Error:", error);
    throw error;
  }
}
