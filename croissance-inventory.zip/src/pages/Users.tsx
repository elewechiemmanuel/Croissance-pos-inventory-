import React, { useContext, useState } from "react";
import { DataContext } from "../components/Layout";
import { useAuth } from "../store/AuthContext";
import { User, UserRole, ActiveSession } from "../types";
import { 
  UserPlus, 
  Search, 
  ShieldCheck, 
  User as UserIcon, 
  Lock, 
  KeyRound, 
  Edit, 
  Trash2, 
  X, 
  CheckCircle2, 
  AlertCircle,
  Eye,
  EyeOff,
  UserCheck,
  UserX,
  Radio,
  Wifi,
  Monitor,
  Smartphone,
  Globe,
  RefreshCw,
  Power,
  Clock,
  MapPin,
  ShieldAlert,
  Laptop
} from "lucide-react";
import { apiCall } from "../lib/api";

function formatTimeAgo(isoString?: string) {
  if (!isoString) return "Never";
  const diffMs = Date.now() - new Date(isoString).getTime();
  if (diffMs < 0 || diffMs < 10000) return "Just now";
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHour = Math.floor(diffMin / 60);
  if (diffHour < 24) return `${diffHour}h ago`;
  return new Date(isoString).toLocaleDateString([], { 
    month: "short", 
    day: "numeric", 
    hour: "2-digit", 
    minute: "2-digit" 
  });
}

function formatLoginTime(isoString?: string) {
  if (!isoString) return "Unknown";
  try {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: true });
  } catch {
    return isoString;
  }
}

export default function UsersPage() {
  const { users = [], activeSessions = [], refreshData } = useContext(DataContext);
  const { user: currentUser } = useAuth();
  const isAdmin = currentUser?.role === "admin";

  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Modal States
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [selectedUserForPassword, setSelectedUserForPassword] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<User | null>(null);
  const [sessionToTerminate, setSessionToTerminate] = useState<ActiveSession | null>(null);
  const [isTerminating, setIsTerminating] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    role: "user" as UserRole,
    status: "Active"
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [lastCreatedUser, setLastCreatedUser] = useState<{ fullName: string; email: string; role: string } | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const isUserOnline = (u: User) => {
    if (u.isOnline) return true;
    const hasSession = activeSessions.some(
      (s: any) => s.userId === u.id && (Date.now() - new Date(s.lastActiveAt).getTime() < 90000)
    );
    if (hasSession) return true;
    if (u.lastActiveAt) {
      return (Date.now() - new Date(u.lastActiveAt).getTime()) < 90000;
    }
    return false;
  };

  const getUserActiveSession = (u: User) => {
    return activeSessions.find((s: any) => s.userId === u.id);
  };

  const filteredUsers = users.filter((u: User) => {
    const matchesSearch = u.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "ALL" || u.role === roleFilter;
    let matchesStatus = true;
    if (statusFilter === "Active") {
      matchesStatus = (u.status || "Active") === "Active";
    } else if (statusFilter === "Inactive") {
      matchesStatus = u.status === "Inactive";
    } else if (statusFilter === "Online") {
      matchesStatus = isUserOnline(u);
    }
    return matchesSearch && matchesRole && matchesStatus;
  });

  const onlineUsers = users.filter((u: User) => isUserOnline(u));
  const totalAdmins = users.filter((u: User) => u.role === "admin").length;
  const totalCashiers = users.filter((u: User) => u.role === "user").length;
  const activeCount = users.filter((u: User) => (u.status || "Active") === "Active").length;
  const inactiveCount = users.filter((u: User) => u.status === "Inactive").length;

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      if (refreshData) {
        await refreshData();
      }
      showToast("Live user sessions refreshed.");
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleForceLogoutSession = async () => {
    if (!sessionToTerminate) return;
    setIsTerminating(true);
    try {
      await apiCall("forceLogoutUser", { userId: sessionToTerminate.userId });
      showToast(`Terminated active session for ${sessionToTerminate.fullName}.`);
      setSessionToTerminate(null);
      if (refreshData) {
        await refreshData();
      }
    } catch (err: any) {
      alert(err.message || "Failed to terminate user session.");
    } finally {
      setIsTerminating(false);
    }
  };

  const handleOpenAddModal = () => {
    setEditingUser(null);
    setFormData({
      fullName: "",
      email: "",
      password: "",
      role: "user",
      status: "Active"
    });
    setShowPassword(false);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (u: User) => {
    setEditingUser(u);
    setFormData({
      fullName: u.fullName,
      email: u.email,
      password: "", // leave blank unless updating
      role: u.role,
      status: u.status || "Active"
    });
    setShowPassword(false);
    setIsModalOpen(true);
  };

  const handleOpenPasswordModal = (u: User) => {
    setSelectedUserForPassword(u);
    setNewPassword("");
    setShowPassword(false);
    setIsPasswordModalOpen(true);
  };

  const handleSaveUser = async (e: React.FormEvent, andAddAnother: boolean = false) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      if (editingUser) {
        const payload: any = {
          id: editingUser.id,
          fullName: formData.fullName,
          email: formData.email,
          role: formData.role,
          status: formData.status
        };
        if (formData.password) {
          payload.password = formData.password;
        }
        await apiCall("updateUser", payload);
        showToast(`User "${formData.fullName}" updated successfully!`);
        setIsModalOpen(false);
      } else {
        if (!formData.password) {
          alert("Please enter a password for the new user.");
          setIsSubmitting(false);
          return;
        }
        await apiCall("addUser", formData);
        showToast(`New user "${formData.fullName}" created successfully!`);
        setLastCreatedUser({
          fullName: formData.fullName,
          email: formData.email,
          role: formData.role
        });

        if (andAddAnother) {
          setFormData({
            fullName: "",
            email: "",
            password: "",
            role: "user",
            status: "Active"
          });
        } else {
          setIsModalOpen(false);
        }
      }
      await refreshData();
    } catch (error: any) {
      alert(error.message || "Failed to save user.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveNewPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForPassword || !newPassword) return;
    setIsSubmitting(true);
    try {
      await apiCall("updateUser", {
        id: selectedUserForPassword.id,
        password: newPassword
      });
      showToast(`Password updated for ${selectedUserForPassword.fullName}`);
      setIsPasswordModalOpen(false);
    } catch (error: any) {
      alert(error.message || "Failed to reset password.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (u: User) => {
    if (u.id === currentUser?.id) {
      alert("You cannot deactivate your own account.");
      return;
    }
    const nextStatus = u.status === "Inactive" ? "Active" : "Inactive";
    try {
      await apiCall("updateUser", { id: u.id, status: nextStatus });
      showToast(`User status set to ${nextStatus}.`);
      await refreshData();
    } catch (error: any) {
      alert(error.message || "Failed to change user status.");
    }
  };

  const handleDeleteUser = async () => {
    if (!deleteConfirmUser) return;
    if (deleteConfirmUser.id === currentUser?.id) {
      alert("You cannot delete your own account.");
      return;
    }
    setIsSubmitting(true);
    try {
      await apiCall("deleteUser", { id: deleteConfirmUser.id });
      showToast(`User "${deleteConfirmUser.fullName}" deleted.`);
      await refreshData();
      setDeleteConfirmUser(null);
    } catch (error: any) {
      alert(error.message || "Failed to delete user.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center max-w-md mx-auto mt-12">
        <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-3" />
        <h2 className="text-xl font-bold text-gray-900">Access Restricted</h2>
        <p className="text-sm text-gray-500 mt-1">
          Only administrators have permission to manage staff accounts and user credentials.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-blue-900 text-white px-5 py-3 rounded-lg shadow-xl flex items-center gap-3 border border-blue-700 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
          <span className="font-medium text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-blue-900">Staff & User Management</h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Create user accounts for station attendants and cashiers, assign permissions, and control login access.
          </p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="bg-amber-500 hover:bg-amber-600 text-white px-5 py-2.5 rounded-lg font-medium flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
        >
          <UserPlus className="w-5 h-5" /> Create New User
        </button>
      </div>

      {/* Banner Shown When a New User is Created */}
      {lastCreatedUser && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-emerald-950">
                User account created: <span className="font-semibold text-emerald-900">{lastCreatedUser.fullName}</span> ({lastCreatedUser.email})
              </p>
              <p className="text-xs text-emerald-700 mt-0.5">
                Role: <span className="capitalize font-semibold">{lastCreatedUser.role}</span> • Account is active and ready for login.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <button
              type="button"
              onClick={() => setLastCreatedUser(null)}
              className="px-3 py-1.5 text-xs text-emerald-700 hover:text-emerald-900 font-medium cursor-pointer"
            >
              Dismiss
            </button>
            <button
              type="button"
              onClick={handleOpenAddModal}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <UserPlus className="w-4 h-4" /> Add Another User
            </button>
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-emerald-100 shadow-sm flex items-center gap-4 relative overflow-hidden">
          <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0 relative">
            <Radio className="w-6 h-6 animate-pulse text-emerald-600" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white animate-ping"></span>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <p className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">Active Users Online</p>
            </div>
            <p className="text-2xl font-bold text-emerald-950 mt-0.5">{onlineUsers.length} Logged In</p>
            <p className="text-xs text-emerald-600 mt-0.5">Live heartbeat active</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Administrators</p>
            <p className="text-2xl font-bold text-amber-700 mt-0.5">{totalAdmins}</p>
            <p className="text-xs text-gray-400 mt-0.5">Full management access</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Cashiers &amp; Staff</p>
            <p className="text-2xl font-bold text-blue-900 mt-0.5">{totalCashiers}</p>
            <p className="text-xs text-gray-400 mt-0.5">POS &amp; sales access</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <UserIcon className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Total Accounts</p>
            <p className="text-2xl font-bold text-gray-900 mt-0.5">{users.length}</p>
            <p className="text-xs text-gray-400 mt-0.5">{activeCount} active &bull; {inactiveCount} inactive</p>
          </div>
        </div>
      </div>

      {/* Real-Time Active Users & Live Sessions Monitor */}
      <div className="bg-white rounded-xl shadow-sm border border-emerald-100 overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-gray-100 bg-gradient-to-r from-emerald-50/70 via-slate-50 to-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <h2 className="text-base font-bold text-gray-900 flex items-center gap-2">
                Live Active Sessions &amp; Terminal Monitor
              </h2>
              <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-semibold rounded-full text-xs">
                {onlineUsers.length} Active Now
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Real-time audit of staff currently authenticated and connected across station terminals and office computers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold shadow-2xs transition-colors cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-blue-800" : "text-gray-500"}`} />
              <span>{isRefreshing ? "Refreshing..." : "Refresh Status"}</span>
            </button>
          </div>
        </div>

        {/* Active Session Cards Grid */}
        <div className="p-5 bg-slate-50/40">
          {onlineUsers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {onlineUsers.map((u: User) => {
                const session = getUserActiveSession(u);
                const isCurrent = u.id === currentUser?.id;
                const lastActive = u.lastActiveAt || session?.lastActiveAt;
                const loginTime = u.lastLogin || session?.loginTime;
                const station = u.currentStation || session?.station || "Main Depot / Station";
                const device = u.deviceInfo || session?.deviceInfo || "Web Browser";
                const ip = u.lastLoginIp || session?.ip || "Local Network";

                return (
                  <div
                    key={u.id}
                    className={`bg-white rounded-xl p-4 border transition-all shadow-xs ${
                      isCurrent ? "border-blue-300 ring-1 ring-blue-100" : "border-emerald-200 hover:border-emerald-300"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 pb-3 border-b border-gray-100">
                      <div className="flex items-center gap-2.5">
                        <div className="relative">
                          <div className="w-10 h-10 rounded-full bg-blue-900 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                            {u.fullName.split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase()}
                          </div>
                          <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full"></span>
                        </div>
                        <div>
                          <div className="font-bold text-sm text-gray-900 flex items-center gap-1.5">
                            <span>{u.fullName}</span>
                            {isCurrent && (
                              <span className="px-1.5 py-0.2 bg-blue-100 text-blue-800 rounded text-[10px] font-bold">
                                You
                              </span>
                            )}
                          </div>
                          <span className="text-xs text-gray-500 font-mono block">{u.email}</span>
                        </div>
                      </div>

                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold shrink-0 ${
                          u.role === "admin"
                            ? "bg-amber-50 text-amber-800 border border-amber-200"
                            : "bg-blue-50 text-blue-800 border border-blue-200"
                        }`}
                      >
                        {u.role === "admin" ? <ShieldCheck className="w-3 h-3" /> : <UserCheck className="w-3 h-3" />}
                        {u.role === "admin" ? "Admin" : "Cashier"}
                      </span>
                    </div>

                    <div className="py-2.5 space-y-1.5 text-xs text-gray-600">
                      <div className="flex items-center gap-2 text-gray-700">
                        <MapPin className="w-3.5 h-3.5 text-blue-900 shrink-0" />
                        <span className="font-semibold text-gray-900">{station}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <Monitor className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                        <span className="truncate" title={device}>{device}</span>
                      </div>

                      <div className="flex items-center justify-between gap-2 text-gray-500 pt-1">
                        <span className="flex items-center gap-1.5">
                          <Globe className="w-3 h-3 text-gray-400" />
                          <span className="font-mono text-[11px]">{ip}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-gray-400" />
                          <span>Login: {formatLoginTime(loginTime)}</span>
                        </span>
                      </div>
                    </div>

                    <div className="pt-2.5 border-t border-gray-100 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 text-emerald-700 font-medium text-[11px]">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                        <span>Active {formatTimeAgo(lastActive)}</span>
                      </div>

                      {!isCurrent ? (
                        <button
                          type="button"
                          onClick={() => {
                            setSessionToTerminate({
                              id: session?.id || `sess_${u.id}`,
                              userId: u.id,
                              fullName: u.fullName,
                              email: u.email,
                              role: u.role,
                              loginTime: loginTime || new Date().toISOString(),
                              lastActiveAt: lastActive || new Date().toISOString(),
                              deviceInfo: device,
                              ip: ip,
                              station: station,
                              isOnline: true
                            });
                          }}
                          className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="Force terminate this user's active session"
                        >
                          <Power className="w-3 h-3" />
                          <span>Terminate</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-blue-800 font-medium">This Terminal</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center bg-white rounded-xl border border-dashed border-gray-200">
              <Wifi className="w-8 h-8 text-gray-300 mx-auto mb-2" />
              <p className="text-sm font-semibold text-gray-700">No external sessions currently online</p>
              <p className="text-xs text-gray-400 mt-0.5">
                When cashiers or attendants log into POS terminals, their live presence will appear here automatically.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Users Table Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Toolbar */}
        <div className="p-4 border-b border-gray-100 flex flex-col md:flex-row gap-3 justify-between items-stretch md:items-center bg-gray-50/50">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search staff by full name or email address..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-gray-700 outline-none"
            >
              <option value="ALL">All Roles</option>
              <option value="admin">Administrators</option>
              <option value="user">Cashiers / Attendants</option>
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-gray-700 outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="Online">🟢 Logged In Now ({onlineUsers.length})</option>
              <option value="Active">Active Accounts</option>
              <option value="Inactive">Inactive Only</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
              <tr>
                <th className="px-5 py-3.5">Staff Member</th>
                <th className="px-5 py-3.5">Email Login</th>
                <th className="px-5 py-3.5">Role</th>
                <th className="px-5 py-3.5">Live Presence &amp; Terminal</th>
                <th className="px-5 py-3.5 text-center">Account Status</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredUsers.map((u: User) => {
                const isCurrent = u.id === currentUser?.id;
                const isActive = (u.status || "Active") === "Active";
                const online = isUserOnline(u);
                const session = getUserActiveSession(u);
                const station = u.currentStation || session?.station;
                const device = u.deviceInfo || session?.deviceInfo;

                return (
                  <tr key={u.id} className="hover:bg-blue-50/30 transition-colors">
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-900 flex items-center justify-center font-bold text-xs">
                            {u.fullName.split(" ").map((n: string) => n[0]).join("").slice(0, 2).toUpperCase()}
                          </div>
                          {online && (
                            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900 flex items-center gap-2">
                            {u.fullName}
                            {isCurrent && (
                              <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold">
                                You
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-gray-400">ID: {u.id}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-5 py-4 font-mono text-xs text-gray-700">
                      {u.email}
                    </td>

                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                        u.role === "admin" 
                          ? "bg-amber-100 text-amber-800" 
                          : "bg-blue-100 text-blue-800"
                      }`}>
                        {u.role === "admin" ? <ShieldCheck className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                        {u.role === "admin" ? "Administrator" : "Cashier / Attendant"}
                      </span>
                    </td>

                    <td className="px-5 py-4">
                      {online ? (
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                            <span>Online Now</span>
                          </div>
                          <div className="text-[11px] text-gray-500 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-gray-400" />
                            <span>{station || "Main Depot / Station"}</span>
                            {device && <span className="text-gray-400">&bull; {device}</span>}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-0.5">
                          <span className="inline-flex items-center gap-1.5 text-xs text-gray-400 font-medium">
                            <span className="w-1.5 h-1.5 rounded-full bg-gray-300"></span>
                            <span>Offline</span>
                          </span>
                          <div className="text-[11px] text-gray-400">
                            Last active: {formatTimeAgo(u.lastActiveAt || u.lastLogin)}
                          </div>
                        </div>
                      )}
                    </td>

                    <td className="px-5 py-4 text-center">
                      <button
                        onClick={() => handleToggleStatus(u)}
                        disabled={isCurrent}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-colors ${
                          isActive 
                            ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-200" 
                            : "bg-red-100 text-red-800 hover:bg-red-200"
                        } ${isCurrent ? 'cursor-not-allowed opacity-80' : 'cursor-pointer'}`}
                        title={isCurrent ? "Cannot deactivate yourself" : "Click to toggle active status"}
                      >
                        {isActive ? "Active" : "Inactive"}
                      </button>
                    </td>

                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenPasswordModal(u)}
                          className="p-1.5 text-amber-700 hover:bg-amber-100/70 rounded-lg transition-colors"
                          title="Reset Password"
                        >
                          <KeyRound className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleOpenEditModal(u)}
                          className="p-1.5 text-blue-700 hover:bg-blue-100/70 rounded-lg transition-colors"
                          title="Edit User Info"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        {!isCurrent && (
                          <button
                            onClick={() => setDeleteConfirmUser(u)}
                            className="p-1.5 text-red-600 hover:bg-red-100/70 rounded-lg transition-colors"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredUsers.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-gray-400">
                    No users found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE / EDIT USER MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center px-6 py-4 bg-blue-900 text-white">
              <div>
                <h3 className="font-bold text-base">
                  {editingUser ? "Edit User Profile" : "Create New Staff Account"}
                </h3>
                <p className="text-xs text-blue-200 mt-0.5">
                  {editingUser ? "Modify details or permissions" : "Register a cashier or administrator"}
                </p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-blue-800 rounded-full transition-colors text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveUser} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Full Name *
                </label>
                <input 
                  required
                  type="text" 
                  placeholder="e.g. Adewale Babatunde"
                  value={formData.fullName} 
                  onChange={e => setFormData({...formData, fullName: e.target.value})}
                  className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Email Address (Login Username) *
                </label>
                <input 
                  required
                  type="email" 
                  placeholder="e.g. adewale@croissance.com"
                  value={formData.email} 
                  onChange={e => setFormData({...formData, email: e.target.value})}
                  className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                />
              </div>

              {/* Password field */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  {editingUser ? "New Password (leave blank to keep unchanged)" : "Password *"}
                </label>
                <div className="relative">
                  <input 
                    type={showPassword ? "text" : "password"} 
                    placeholder={editingUser ? "••••••••" : "Minimum 6 characters"}
                    value={formData.password} 
                    onChange={e => setFormData({...formData, password: e.target.value})}
                    required={!editingUser}
                    className="w-full pl-3 pr-10 py-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Role Selection */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  System Role & Permission Level *
                </label>
                <div className="grid grid-cols-2 gap-3 mt-1">
                  <div 
                    onClick={() => setFormData({...formData, role: "user"})}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      formData.role === "user" 
                        ? "border-blue-700 bg-blue-50/60 ring-2 ring-blue-500/20" 
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <UserCheck className={`w-4 h-4 ${formData.role === "user" ? "text-blue-700" : "text-gray-400"}`} />
                      <span className="font-bold text-xs text-gray-900">Cashier / Staff</span>
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1">
                      Can record sales, print customer receipts, and search inventory.
                    </p>
                  </div>

                  <div 
                    onClick={() => setFormData({...formData, role: "admin"})}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      formData.role === "admin" 
                        ? "border-amber-600 bg-amber-50/60 ring-2 ring-amber-500/20" 
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <ShieldCheck className={`w-4 h-4 ${formData.role === "admin" ? "text-amber-700" : "text-gray-400"}`} />
                      <span className="font-bold text-xs text-gray-900">Administrator</span>
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1">
                      Full control: adjust prices, view profit, create users, modify stock.
                    </p>
                  </div>
                </div>
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Account Status
                </label>
                <select
                  value={formData.status}
                  onChange={e => setFormData({...formData, status: e.target.value})}
                  className="w-full p-2.5 border border-gray-200 rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Active">Active (User can log in)</option>
                  <option value="Inactive">Inactive (Login blocked)</option>
                </select>
              </div>

              {/* Modal Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-gray-100">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="px-4 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-50 cursor-pointer"
                >
                  Cancel
                </button>
                <div className="flex items-center gap-2">
                  {!editingUser && (
                    <button 
                      type="button" 
                      disabled={isSubmitting}
                      onClick={(e) => handleSaveUser(e, true)}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-bold transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      {isSubmitting ? "Saving..." : "Save & Add Another User"}
                    </button>
                  )}
                  <button 
                    type="submit" 
                    disabled={isSubmitting} 
                    className="px-5 py-2 bg-blue-900 text-white rounded-lg text-xs font-bold hover:bg-blue-800 transition-colors shadow-xs cursor-pointer"
                  >
                    {isSubmitting ? "Saving..." : (editingUser ? "Save Changes" : "Create User")}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RESET PASSWORD MODAL */}
      {isPasswordModalOpen && selectedUserForPassword && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-in fade-in zoom-in-95">
            <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mb-3">
              <KeyRound className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-gray-900">Reset Password</h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Assign a new login password for <span className="font-semibold text-gray-800">{selectedUserForPassword.fullName}</span> ({selectedUserForPassword.email}).
            </p>

            <form onSubmit={handleSaveNewPassword} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">New Password *</label>
                <div className="relative">
                  <input
                    required
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter new password"
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    className="w-full pl-3 pr-10 py-2 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsPasswordModalOpen(false)}
                  className="px-4 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !newPassword}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-bold transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? "Updating..." : "Update Password"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteConfirmUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">Delete User Account?</h3>
            <p className="text-sm text-gray-500 mt-1">
              Are you sure you want to permanently delete <span className="font-semibold text-gray-800">"{deleteConfirmUser.fullName}"</span> ({deleteConfirmUser.email})? This user will no longer be able to log in.
            </p>
            <div className="flex justify-end gap-3 mt-6">
              <button 
                type="button"
                onClick={() => setDeleteConfirmUser(null)}
                className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                type="button"
                onClick={handleDeleteUser}
                disabled={isSubmitting}
                className="px-5 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 disabled:opacity-50 transition-colors"
              >
                {isSubmitting ? "Deleting..." : "Yes, Delete User"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* FORCE TERMINATE SESSION MODAL */}
      {sessionToTerminate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center mb-4">
              <Power className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">Terminate Active Session?</h3>
            <p className="text-sm text-gray-500 mt-1">
              You are about to disconnect and force sign out <span className="font-semibold text-gray-800">{sessionToTerminate.fullName}</span> ({sessionToTerminate.email}).
            </p>

            <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5 text-xs text-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Terminal Station:</span>
                <span className="font-semibold text-slate-900">{sessionToTerminate.station || "Depot / Station"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Device &amp; Browser:</span>
                <span className="font-mono text-[11px] text-slate-900">{sessionToTerminate.deviceInfo || "Web Terminal"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Connected IP:</span>
                <span className="font-mono text-[11px] text-slate-900">{sessionToTerminate.ip || "Local Network"}</span>
              </div>
            </div>

            <p className="text-xs text-red-600 mt-3">
              This terminal will immediately lose its authenticated session and be redirected to the login screen.
            </p>

            <div className="flex justify-end gap-3 mt-6">
              <button 
                type="button"
                onClick={() => setSessionToTerminate(null)}
                className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                type="button"
                onClick={handleForceLogoutSession}
                disabled={isTerminating}
                className="px-5 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 disabled:opacity-50 transition-colors flex items-center gap-1.5"
              >
                {isTerminating ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Disconnecting...</span>
                  </>
                ) : (
                  <>
                    <Power className="w-4 h-4" />
                    <span>Terminate Session</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
