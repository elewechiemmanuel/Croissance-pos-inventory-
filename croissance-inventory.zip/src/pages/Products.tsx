import React, { useContext, useState, useMemo } from "react";
import { DataContext } from "../components/Layout";
import { useAuth } from "../store/AuthContext";
import { Product } from "../types";
import { formatCurrency } from "../lib/utils";
import { 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2, 
  X, 
  AlertTriangle, 
  Package, 
  TrendingUp, 
  DollarSign, 
  SlidersHorizontal,
  CheckCircle2,
  Tag,
  FileSpreadsheet,
  Download,
  Upload
} from "lucide-react";
import { apiCall } from "../lib/api";
import CsvInventoryImportModal from "../components/CsvInventoryImportModal";
import { exportInventoryToCsv, downloadCsvFile } from "../lib/csvHelper";

const PRODUCT_PRESETS = [
  // Petrol / PMS
  { name: "Petrol (PMS) - Dispenser Pump", category: "Petrol", type: "Petrol", salesType: "Retail" as const, unit: "Litre", buyingPrice: 700, sellingPrice: 760, wholesalePrice: 740, minStock: 1000 },
  { name: "Petrol (PMS) - Bulk Tanker (33,000L)", category: "Petrol", type: "Petrol", salesType: "Wholesale" as const, unit: "Litre", buyingPrice: 680, sellingPrice: 720, wholesalePrice: 710, minStock: 5000 },

  // Diesel / AGO
  { name: "Diesel (AGO) - Pump Dispenser", category: "Diesel", type: "Diesel", salesType: "Retail" as const, unit: "Litre", buyingPrice: 1100, sellingPrice: 1350, wholesalePrice: 1300, minStock: 500 },
  { name: "Diesel (AGO) - Bulk Tanker", category: "Diesel", type: "Diesel", salesType: "Wholesale" as const, unit: "Litre", buyingPrice: 1050, sellingPrice: 1250, wholesalePrice: 1180, minStock: 2000 },

  // Kerosene / DPK
  { name: "Kerosene (DPK) - Pump / Retail", category: "Kerosene", type: "Kerosene", salesType: "Retail" as const, unit: "Litre", buyingPrice: 1150, sellingPrice: 1400, wholesalePrice: 1350, minStock: 300 },

  // LPG Cooking Gas
  { name: "LPG 50kg Refill / Cylinder", category: "LPG", type: "LPG", salesType: "Wholesale" as const, unit: "KG", buyingPrice: 42000, sellingPrice: 52000, wholesalePrice: 49000, minStock: 5 },
  { name: "LPG 25kg Refill / Cylinder", category: "LPG", type: "LPG", salesType: "Retail" as const, unit: "KG", buyingPrice: 21000, sellingPrice: 26000, wholesalePrice: 24500, minStock: 10 },
  { name: "LPG 12.5kg Refill / Cylinder", category: "LPG", type: "LPG", salesType: "Retail" as const, unit: "KG", buyingPrice: 10500, sellingPrice: 13000, wholesalePrice: 12200, minStock: 15 },
  { name: "LPG 6kg Refill / Cylinder", category: "LPG", type: "LPG", salesType: "Retail" as const, unit: "KG", buyingPrice: 5100, sellingPrice: 6500, wholesalePrice: 6000, minStock: 20 },
  { name: "LPG 3kg Refill / Cylinder", category: "LPG", type: "LPG", salesType: "Retail" as const, unit: "KG", buyingPrice: 2600, sellingPrice: 3500, wholesalePrice: 3200, minStock: 25 },

  // Engine Oils & Lubricants
  { name: "Heavy Duty Engine Oil 15W-40 (4L)", category: "Lubricants", type: "Lubricant", salesType: "Retail" as const, unit: "Unit", buyingPrice: 14000, sellingPrice: 18500, wholesalePrice: 17000, minStock: 10 },
  { name: "Multi-Grade Engine Oil 20W-50 (4L)", category: "Lubricants", type: "Lubricant", salesType: "Retail" as const, unit: "Unit", buyingPrice: 12500, sellingPrice: 16000, wholesalePrice: 15000, minStock: 12 },
  { name: "Full Synthetic Engine Oil 5W-30 (4L)", category: "Lubricants", type: "Lubricant", salesType: "Retail" as const, unit: "Unit", buyingPrice: 18000, sellingPrice: 24000, wholesalePrice: 22000, minStock: 8 },
  { name: "Automatic Transmission Fluid ATF (1L)", category: "Lubricants", type: "Lubricant", salesType: "Retail" as const, unit: "Bottle", buyingPrice: 3200, sellingPrice: 4500, wholesalePrice: 4000, minStock: 15 },

  // Gas Accessories & Cylinders
  { name: "Low Pressure Gas Regulator with Gauge", category: "Accessories", type: "Accessory", salesType: "Retail" as const, unit: "Unit", buyingPrice: 4500, sellingPrice: 6500, wholesalePrice: 5800, minStock: 15 },
  { name: "High Pressure Industrial Regulator", category: "Accessories", type: "Accessory", salesType: "Retail" as const, unit: "Unit", buyingPrice: 8500, sellingPrice: 12000, wholesalePrice: 10500, minStock: 10 },
  { name: "Reinforced Gas Hose (2 Metres) + Clamps", category: "Accessories", type: "Accessory", salesType: "Retail" as const, unit: "Unit", buyingPrice: 2200, sellingPrice: 3500, wholesalePrice: 3000, minStock: 25 },
  { name: "Gas Cooker Double Burner Tabletop", category: "Gas Cookers", type: "Hardware", salesType: "Retail" as const, unit: "Unit", buyingPrice: 16000, sellingPrice: 22000, wholesalePrice: 20000, minStock: 6 },
  { name: "Standard 12.5kg Empty Cylinder (Brand New)", category: "Accessories", type: "Cylinder", salesType: "Retail" as const, unit: "Unit", buyingPrice: 28000, sellingPrice: 35000, wholesalePrice: 32000, minStock: 10 },
  { name: "Standard 6kg Camping Cylinder (Brand New)", category: "Accessories", type: "Cylinder", salesType: "Retail" as const, unit: "Unit", buyingPrice: 15000, sellingPrice: 19500, wholesalePrice: 18000, minStock: 15 }
];

export default function Products() {
  const { products = [], refreshData } = useContext(DataContext);
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Quick value adjustment modal state
  const [quickAdjustProduct, setQuickAdjustProduct] = useState<Product | null>(null);
  const [quickAdjustForm, setQuickAdjustForm] = useState({
    sellingPrice: 0,
    wholesalePrice: 0,
    buyingPrice: 0,
    currentStock: 0,
    reason: ""
  });

  // Product Delete Confirmation
  const [deleteConfirmProduct, setDeleteConfirmProduct] = useState<Product | null>(null);

  // CSV Import Modal State
  const [isCsvImportOpen, setIsCsvImportOpen] = useState(false);

  const handleExportCsv = () => {
    try {
      const csv = exportInventoryToCsv(products);
      const dateStr = new Date().toISOString().split("T")[0];
      downloadCsvFile(csv, `croissance_inventory_${dateStr}.csv`);
      showToast(`Exported ${products.length} products to CSV.`);
    } catch (e: any) {
      alert("Failed to export inventory: " + (e?.message || "Unknown error"));
    }
  };

  // Form State for Add / Edit
  const [formData, setFormData] = useState({
    name: "",
    category: "Petrol",
    type: "Petrol",
    salesType: "Retail" as "Retail" | "Wholesale",
    unit: "Litre",
    buyingPrice: 0,
    sellingPrice: 0,
    wholesalePrice: 0,
    openingStock: 0,
    currentStock: 0,
    minStock: 10,
    status: "Active"
  });

  const [isCustomCategory, setIsCustomCategory] = useState(false);
  const [customCategoryInput, setCustomCategoryInput] = useState("");
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const STANDARD_CATEGORIES = [
    "Petrol",
    "Diesel",
    "LPG",
    "Kerosene",
    "Lubricants",
    "Accessories",
    "Gas Cookers",
    "Industrial Gas",
    "Heavy Equipment"
  ];

  // Dynamic categories from all current products + standards
  const allCategories = useMemo(() => {
    const fromProducts = products.map((p: Product) => p.category).filter(Boolean);
    return Array.from(new Set([...STANDARD_CATEGORIES, ...fromProducts]));
  }, [products]);

  // Inventory KPI calculations
  const totalCostValue = products.reduce((sum: number, p: Product) => sum + (p.currentStock * (p.buyingPrice || 0)), 0);
  const totalRetailValue = products.reduce((sum: number, p: Product) => sum + (p.currentStock * (p.sellingPrice || 0)), 0);
  const lowStockCount = products.filter((p: Product) => p.currentStock <= p.minStock).length;

  const filteredProducts = products.filter((p: Product) => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.unit.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "ALL" || p.category.toUpperCase() === categoryFilter.toUpperCase();
    const matchesStatus = statusFilter === "ALL" || 
      (statusFilter === "ACTIVE" && p.status === "Active") ||
      (statusFilter === "INACTIVE" && p.status === "Inactive") ||
      (statusFilter === "LOW_STOCK" && p.currentStock <= p.minStock);
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleOpenAddModal = () => {
    setEditingProduct(null);
    setIsCustomCategory(false);
    setCustomCategoryInput("");
    setFormData({
      name: "",
      category: "Petrol",
      type: "Petrol",
      salesType: "Retail",
      unit: "Litre",
      buyingPrice: 0,
      sellingPrice: 0,
      wholesalePrice: 0,
      openingStock: 0,
      currentStock: 0,
      minStock: 10,
      status: "Active"
    });
    setIsModalOpen(true);
  };

  const handleApplyPreset = (presetIndex: number) => {
    const preset = PRODUCT_PRESETS[presetIndex];
    if (!preset) return;
    setIsCustomCategory(false);
    setCustomCategoryInput("");
    setFormData(prev => ({
      ...prev,
      name: preset.name,
      category: preset.category,
      type: preset.type,
      salesType: preset.salesType as "Retail" | "Wholesale",
      unit: preset.unit,
      buyingPrice: preset.buyingPrice,
      sellingPrice: preset.sellingPrice,
      wholesalePrice: preset.wholesalePrice,
      minStock: preset.minStock
    }));
  };

  const handleOpenEditModal = (product: Product) => {
    setEditingProduct(product);
    const isCustom = !STANDARD_CATEGORIES.includes(product.category);
    setIsCustomCategory(isCustom);
    setCustomCategoryInput(isCustom ? product.category : "");
    setFormData({
      name: product.name,
      category: product.category,
      type: product.type || "General",
      salesType: product.salesType || "Retail",
      unit: product.unit,
      buyingPrice: product.buyingPrice,
      sellingPrice: product.sellingPrice,
      wholesalePrice: product.wholesalePrice,
      openingStock: product.openingStock,
      currentStock: product.currentStock,
      minStock: product.minStock,
      status: product.status || "Active"
    });
    setIsModalOpen(true);
  };

  const handleOpenQuickAdjust = (product: Product) => {
    setQuickAdjustProduct(product);
    setQuickAdjustForm({
      sellingPrice: product.sellingPrice,
      wholesalePrice: product.wholesalePrice,
      buyingPrice: product.buyingPrice,
      currentStock: product.currentStock,
      reason: ""
    });
  };

  const handleSaveProduct = async (e: React.FormEvent, andAddAnother = false) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const finalCategory = isCustomCategory 
        ? (customCategoryInput.trim() || "General") 
        : formData.category;

      if (editingProduct) {
        await apiCall("updateProduct", {
          id: editingProduct.id,
          ...formData,
          category: finalCategory,
          buyingPrice: Number(formData.buyingPrice),
          sellingPrice: Number(formData.sellingPrice),
          wholesalePrice: Number(formData.wholesalePrice),
          currentStock: Number(formData.currentStock),
          openingStock: Number(formData.openingStock),
          minStock: Number(formData.minStock)
        });
        showToast(`Product "${formData.name}" values successfully updated!`);
        setIsModalOpen(false);
      } else {
        await apiCall("addProduct", {
          ...formData,
          category: finalCategory,
          buyingPrice: Number(formData.buyingPrice),
          sellingPrice: Number(formData.sellingPrice),
          wholesalePrice: Number(formData.wholesalePrice),
          openingStock: Number(formData.openingStock),
          currentStock: Number(formData.currentStock || formData.openingStock),
          minStock: Number(formData.minStock)
        });
        showToast(`New product "${formData.name}" added successfully!`);
        if (andAddAnother) {
          setFormData({
            name: "",
            category: finalCategory,
            type: formData.type || "General",
            salesType: "Retail",
            unit: formData.unit || "Unit",
            buyingPrice: 0,
            sellingPrice: 0,
            wholesalePrice: 0,
            openingStock: 0,
            currentStock: 0,
            minStock: 10,
            status: "Active"
          });
        } else {
          setIsModalOpen(false);
        }
      }
      await refreshData();
    } catch (error: any) {
      alert(error.message || "Failed to save product.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSaveQuickAdjust = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickAdjustProduct) return;
    setIsSubmitting(true);
    try {
      await apiCall("updateProduct", {
        id: quickAdjustProduct.id,
        sellingPrice: Number(quickAdjustForm.sellingPrice),
        wholesalePrice: Number(quickAdjustForm.wholesalePrice),
        buyingPrice: Number(quickAdjustForm.buyingPrice),
        currentStock: Number(quickAdjustForm.currentStock),
        reason: quickAdjustForm.reason?.trim() || undefined
      });
      showToast(`Adjusted prices & stock for "${quickAdjustProduct.name}"! Recorded in Audit Log.`);
      await refreshData();
      setQuickAdjustProduct(null);
    } catch (error: any) {
      alert(error.message || "Failed to adjust product values.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteProduct = async () => {
    if (!deleteConfirmProduct) return;
    setIsSubmitting(true);
    try {
      await apiCall("deleteProduct", { id: deleteConfirmProduct.id });
      showToast(`Product "${deleteConfirmProduct.name}" removed.`);
      await refreshData();
      setDeleteConfirmProduct(null);
    } catch (error: any) {
      alert(error.message || "Failed to delete product.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-blue-900 text-white px-5 py-3 rounded-lg shadow-xl flex items-center gap-3 border border-blue-700 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
          <span className="font-medium text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-blue-900">Products & Inventory Valuation</h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Manage product catalogue, configure retail & wholesale prices, adjust stock levels, and monitor stock values.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-2.5 bg-white hover:bg-gray-50 text-gray-700 border border-gray-200 rounded-lg text-sm font-medium flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
            title="Export all current products to a CSV file"
          >
            <Download className="w-4 h-4 text-gray-500" />
            <span>Export CSV</span>
          </button>

          {isAdmin && (
            <>
              <button
                type="button"
                onClick={() => setIsCsvImportOpen(true)}
                className="px-4 py-2.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-sm font-medium flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
                title="Import inventory data via CSV file"
              >
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                <span>Import CSV</span>
              </button>

              <button 
                onClick={handleOpenAddModal}
                className="bg-amber-500 hover:bg-amber-600 text-white px-5 py-2.5 rounded-lg font-medium flex items-center gap-2 shadow-sm transition-colors cursor-pointer"
              >
                <Plus className="w-5 h-5" /> Add New Product
              </button>
            </>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-blue-50 text-blue-800 flex items-center justify-center shrink-0">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Total Products</p>
            <p className="text-2xl font-bold text-gray-900 mt-0.5">{products.length}</p>
            <p className="text-xs text-gray-400 mt-0.5">{products.filter((p: Product) => p.status === 'Active').length} Active</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Total Stock Value (Cost)</p>
            <p className="text-xl font-bold text-emerald-700 mt-0.5">{formatCurrency(totalCostValue)}</p>
            <p className="text-xs text-gray-400 mt-0.5">Capital invested in stock</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Expected Retail Value</p>
            <p className="text-xl font-bold text-blue-900 mt-0.5">{formatCurrency(totalRetailValue)}</p>
            <p className="text-xs text-gray-400 mt-0.5">Potential revenue</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4">
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center shrink-0 ${lowStockCount > 0 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Low Stock Alerts</p>
            <p className={`text-2xl font-bold mt-0.5 ${lowStockCount > 0 ? 'text-red-600' : 'text-gray-900'}`}>{lowStockCount}</p>
            <p className="text-xs text-gray-400 mt-0.5">{lowStockCount > 0 ? 'Immediate reorder needed' : 'All stocks healthy'}</p>
          </div>
        </div>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Search and Filters Toolbar */}
        <div className="p-4 border-b border-gray-100 flex flex-col md:flex-row gap-3 justify-between items-stretch md:items-center bg-gray-50/50">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input 
              type="text" 
              placeholder="Search by product name, category, or unit..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 text-xs text-gray-500 font-medium">
              <Filter className="w-3.5 h-3.5" />
              <span>Category:</span>
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-gray-700 outline-none focus:border-blue-500"
            >
              <option value="ALL">All Categories ({products.length})</option>
              {allCategories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>

            <div className="flex items-center gap-1 text-xs text-gray-500 font-medium ml-2">
              <span>Status:</span>
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs font-medium text-gray-700 outline-none focus:border-blue-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">Active Only</option>
              <option value="LOW_STOCK">Low Stock Alert</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>
        </div>
        
        {/* Products Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider font-semibold border-b border-gray-100">
              <tr>
                <th className="px-5 py-3.5">Product Name & Category</th>
                <th className="px-4 py-3.5 text-center">Unit</th>
                <th className="px-4 py-3.5 text-right">Cost Price (Buy)</th>
                <th className="px-4 py-3.5 text-right">Retail Price</th>
                <th className="px-4 py-3.5 text-right">Wholesale Price</th>
                <th className="px-4 py-3.5 text-right">Current Stock</th>
                <th className="px-4 py-3.5 text-right">Stock Value (Cost)</th>
                <th className="px-4 py-3.5 text-center">Status</th>
                {isAdmin && <th className="px-5 py-3.5 text-right">Admin Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredProducts.map((p: Product) => {
                const isLow = p.currentStock <= p.minStock;
                const costVal = p.currentStock * (p.buyingPrice || 0);
                const retailVal = p.currentStock * (p.sellingPrice || 0);

                return (
                  <tr key={p.id} className="hover:bg-blue-50/30 transition-colors">
                    <td className="px-5 py-4">
                      <div className="font-semibold text-gray-900">{p.name}</div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs px-2 py-0.5 rounded bg-blue-100/70 text-blue-800 font-medium">
                          {p.category}
                        </span>
                        <span className="text-xs text-gray-400">
                          {p.salesType || "Retail & Wholesale"}
                        </span>
                      </div>
                    </td>

                    <td className="px-4 py-4 text-center">
                      <span className="inline-block px-2.5 py-1 rounded bg-gray-100 text-gray-700 text-xs font-semibold">
                        {p.unit}
                      </span>
                    </td>

                    <td className="px-4 py-4 text-right font-medium text-gray-600">
                      {formatCurrency(p.buyingPrice || 0)}
                    </td>

                    <td className="px-4 py-4 text-right font-bold text-blue-900">
                      {formatCurrency(p.sellingPrice || 0)}
                    </td>

                    <td className="px-4 py-4 text-right font-medium text-amber-700">
                      {formatCurrency(p.wholesalePrice || 0)}
                    </td>

                    <td className="px-4 py-4 text-right">
                      <div className="flex flex-col items-end">
                        <span className={`font-bold ${isLow ? 'text-red-600 font-extrabold' : 'text-gray-900'}`}>
                          {p.currentStock.toLocaleString()} {p.unit}
                        </span>
                        <span className="text-[11px] text-gray-400">
                          Min: {p.minStock} {p.unit}
                        </span>
                      </div>
                    </td>

                    <td className="px-4 py-4 text-right">
                      <div className="font-semibold text-emerald-700">{formatCurrency(costVal)}</div>
                      <div className="text-[11px] text-gray-400">Retail: {formatCurrency(retailVal)}</div>
                    </td>

                    <td className="px-4 py-4 text-center">
                      {isLow ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">
                          <AlertTriangle className="w-3 h-3" /> Low Stock
                        </span>
                      ) : (
                        <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold ${p.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}`}>
                          {p.status || "Active"}
                        </span>
                      )}
                    </td>

                    {isAdmin && (
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button 
                            onClick={() => handleOpenQuickAdjust(p)}
                            className="p-1.5 text-amber-700 hover:bg-amber-100/70 rounded-lg transition-colors"
                            title="Quick Adjust Value & Stock"
                          >
                            <SlidersHorizontal className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleOpenEditModal(p)}
                            className="p-1.5 text-blue-700 hover:bg-blue-100/70 rounded-lg transition-colors"
                            title="Full Product Edit"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => setDeleteConfirmProduct(p)}
                            className="p-1.5 text-red-600 hover:bg-red-100/70 rounded-lg transition-colors"
                            title="Delete Product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}

              {filteredProducts.length === 0 && (
                <tr>
                  <td colSpan={isAdmin ? 9 : 8} className="px-6 py-12 text-center text-gray-500">
                    <Package className="w-10 h-10 mx-auto text-gray-300 mb-2" />
                    <p className="font-medium text-gray-700">No products matching your search or filters.</p>
                    <p className="text-xs text-gray-400 mt-1">Try clearing your filters or click "Add New Product" to add more items.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* FULL ADD / EDIT MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-gray-100 bg-blue-900 text-white">
              <div>
                <h2 className="text-lg font-bold">
                  {editingProduct ? "Modify Product Values & Details" : "Add New Oil & Gas Product"}
                </h2>
                <p className="text-xs text-blue-200 mt-0.5">
                  {editingProduct ? "Update pricing, stock levels, or specifications" : "Register a new product to your inventory catalog"}
                </p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)} 
                className="p-1.5 hover:bg-blue-800 rounded-full transition-colors text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSaveProduct} className="p-6 overflow-y-auto space-y-5">
              {/* Preset Selector for Quick Addition */}
              {!editingProduct && (
                <div className="p-3 bg-amber-50 rounded-xl border border-amber-200">
                  <label className="block text-xs font-bold text-amber-900 uppercase tracking-wider mb-1.5">
                    Quick Autofill from Standard Oil & Gas Catalog:
                  </label>
                  <select 
                    onChange={(e) => handleApplyPreset(Number(e.target.value))}
                    defaultValue=""
                    className="w-full bg-white p-2 border border-amber-300 rounded-lg text-xs font-medium text-gray-800 outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="" disabled>-- Select a standard product template (optional) --</option>
                    {PRODUCT_PRESETS.map((preset, idx) => (
                      <option key={idx} value={idx}>
                        {preset.name} ({preset.category} - {preset.salesType})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Section 1: Basic Information */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-blue-900 mb-3 pb-1 border-b border-gray-100">
                  1. Product Specifications
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Product Name *</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="e.g. LPG 12.5kg Cylinder Refill, Diesel (AGO) Bulk"
                      value={formData.name} 
                      onChange={e => setFormData({...formData, name: e.target.value})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="block text-xs font-semibold text-gray-700">Category *</label>
                      <button
                        type="button"
                        onClick={() => {
                          setIsCustomCategory(!isCustomCategory);
                          if (!isCustomCategory) {
                            setCustomCategoryInput("");
                          }
                        }}
                        className="text-[11px] text-blue-700 hover:text-blue-900 font-medium underline cursor-pointer"
                      >
                        {isCustomCategory ? "Standard Category" : "+ Custom Category"}
                      </button>
                    </div>

                    {!isCustomCategory ? (
                      <select 
                        value={formData.category} 
                        onChange={e => {
                          if (e.target.value === "OTHER_CUSTOM") {
                            setIsCustomCategory(true);
                            setCustomCategoryInput("");
                          } else {
                            setFormData({...formData, category: e.target.value});
                          }
                        }} 
                        className="w-full p-2.5 border border-gray-200 rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Petrol">Petrol (PMS - Premium Motor Spirit)</option>
                        <option value="Diesel">Diesel (AGO - Automotive Gas Oil)</option>
                        <option value="LPG">LPG (Cooking Gas)</option>
                        <option value="Kerosene">Kerosene (DPK - Dual Purpose)</option>
                        <option value="Lubricants">Lubricants / Engine Oils</option>
                        <option value="Accessories">Accessories & Cylinders</option>
                        <option value="Gas Cookers">Gas Cookers & Burners</option>
                        <option value="Industrial Gas">Industrial Gases (Oxygen, Argon, etc.)</option>
                        <option value="Heavy Equipment">Heavy Equipment & Machinery</option>
                        <option value="OTHER_CUSTOM">✨ Other / Custom Category...</option>
                      </select>
                    ) : (
                      <div className="space-y-1.5">
                        <input
                          required
                          type="text"
                          placeholder="e.g. Solar, Aviation Fuel, Chemicals, Car Batteries"
                          value={customCategoryInput}
                          onChange={e => setCustomCategoryInput(e.target.value)}
                          className="w-full p-2.5 border border-blue-400 bg-blue-50/30 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500"
                          autoFocus
                        />
                        <p className="text-[11px] text-gray-500">Admins can create any product category for the station.</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Unit of Measurement *</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="Litre, KG, Unit, Drum, Carton, Bottle"
                      value={formData.unit} 
                      onChange={e => setFormData({...formData, unit: e.target.value})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                    />
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {["Litre", "KG", "Unit", "Drum", "Carton", "Bottle", "Cylinder"].map(u => (
                        <button
                          key={u}
                          type="button"
                          onClick={() => setFormData({...formData, unit: u})}
                          className={`text-[10px] px-2 py-0.5 rounded border transition-colors cursor-pointer ${
                            formData.unit === u 
                              ? "bg-blue-900 text-white border-blue-900" 
                              : "bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100"
                          }`}
                        >
                          {u}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Product Classification / Type</label>
                    <select 
                      value={formData.type} 
                      onChange={e => setFormData({...formData, type: e.target.value})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Petrol">Petrol (PMS)</option>
                      <option value="Diesel">Diesel (AGO)</option>
                      <option value="LPG">LPG (Cooking Gas)</option>
                      <option value="Kerosene">Kerosene (DPK)</option>
                      <option value="Lubricant">Lubricant / Oil</option>
                      <option value="Accessory">Accessory / Cylinder</option>
                      <option value="Hardware">Hardware / Equipment</option>
                      <option value="General">General Product</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Sales Type</label>
                    <select 
                      value={formData.salesType} 
                      onChange={e => setFormData({...formData, salesType: e.target.value as "Retail" | "Wholesale"})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Retail">Retail</option>
                      <option value="Wholesale">Wholesale</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Status</label>
                    <select 
                      value={formData.status} 
                      onChange={e => setFormData({...formData, status: e.target.value})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm bg-white outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="Active">Active (Available for sales)</option>
                      <option value="Inactive">Inactive (Archived)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Section 2: Valuation & Pricing */}
              <div>
                <div className="flex justify-between items-center mb-3 pb-1 border-b border-gray-100">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-blue-900">
                    2. Pricing & Profit Margins (₦)
                  </h3>
                  {formData.sellingPrice > 0 && formData.buyingPrice > 0 && (
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      Est. Retail Margin: {(((formData.sellingPrice - formData.buyingPrice) / formData.sellingPrice) * 100).toFixed(1)}%
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Buying Price / Cost (₦) *
                    </label>
                    <input 
                      required 
                      type="number" 
                      min="0" 
                      step="any"
                      value={formData.buyingPrice} 
                      onChange={e => setFormData({...formData, buyingPrice: Number(e.target.value)})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                    />
                    <span className="text-[11px] text-gray-400 mt-0.5 block">Purchase cost per unit</span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Retail Selling Price (₦) *
                    </label>
                    <input 
                      required 
                      type="number" 
                      min="0" 
                      step="any"
                      value={formData.sellingPrice} 
                      onChange={e => setFormData({...formData, sellingPrice: Number(e.target.value)})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 font-semibold text-blue-900" 
                    />
                    <span className="text-[11px] text-gray-400 mt-0.5 block">Pump / Standard rate</span>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Wholesale Price (₦) *
                    </label>
                    <input 
                      required 
                      type="number" 
                      min="0" 
                      step="any"
                      value={formData.wholesalePrice} 
                      onChange={e => setFormData({...formData, wholesalePrice: Number(e.target.value)})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500 font-semibold text-amber-800" 
                    />
                    <span className="text-[11px] text-gray-400 mt-0.5 block">Bulk / Commercial rate</span>
                  </div>
                </div>
              </div>

              {/* Section 3: Stock Levels & Valuation */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-blue-900 mb-3 pb-1 border-b border-gray-100">
                  3. Stock Levels & Real-Time Inventory Value
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      {editingProduct ? "Current Available Stock" : "Initial Stock (Opening)"} *
                    </label>
                    <input 
                      required 
                      type="number" 
                      min="0" 
                      step="any"
                      value={editingProduct ? formData.currentStock : formData.openingStock} 
                      onChange={e => {
                        const val = Number(e.target.value);
                        if (editingProduct) {
                          setFormData({...formData, currentStock: val});
                        } else {
                          setFormData({...formData, openingStock: val, currentStock: val});
                        }
                      }} 
                      className="w-full p-2.5 border border-blue-300 bg-blue-50/40 rounded-lg text-sm font-bold text-blue-900 outline-none focus:ring-2 focus:ring-blue-500" 
                    />
                    <span className="text-[11px] text-gray-500 mt-0.5 block">In {formData.unit || "units"}</span>
                  </div>

                  {editingProduct && (
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        Recorded Opening Stock
                      </label>
                      <input 
                        type="number" 
                        min="0" 
                        step="any"
                        value={formData.openingStock} 
                        onChange={e => setFormData({...formData, openingStock: Number(e.target.value)})} 
                        className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                      />
                      <span className="text-[11px] text-gray-400 mt-0.5 block">Starting stock benchmark</span>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      Min Stock Threshold *
                    </label>
                    <input 
                      required 
                      type="number" 
                      min="0" 
                      step="any"
                      value={formData.minStock} 
                      onChange={e => setFormData({...formData, minStock: Number(e.target.value)})} 
                      className="w-full p-2.5 border border-gray-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500" 
                    />
                    <span className="text-[11px] text-gray-400 mt-0.5 block">Triggers low-stock warning</span>
                  </div>
                </div>

                {/* Stock Value Live Summary */}
                <div className="mt-4 p-3 bg-gray-50 rounded-xl border border-gray-200 flex flex-col sm:flex-row justify-between items-start sm:items-center text-xs gap-2">
                  <div>
                    <span className="text-gray-500">Inventory Stock Value at Cost:</span>{" "}
                    <span className="font-bold text-emerald-700 text-sm">
                      {formatCurrency(((editingProduct ? formData.currentStock : formData.openingStock) || 0) * (formData.buyingPrice || 0))}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Retail Revenue Potential:</span>{" "}
                    <span className="font-bold text-blue-900 text-sm">
                      {formatCurrency(((editingProduct ? formData.currentStock : formData.openingStock) || 0) * (formData.sellingPrice || 0))}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-gray-100">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)} 
                  className="px-5 py-2.5 border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <div className="flex items-center gap-2">
                  {!editingProduct && (
                    <button 
                      type="button" 
                      disabled={isSubmitting} 
                      onClick={(e) => handleSaveProduct(e, true)}
                      className="px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-sm font-bold transition-colors shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" />
                      {isSubmitting ? "Saving..." : "Save & Add Another Product"}
                    </button>
                  )}
                  <button 
                    type="submit" 
                    disabled={isSubmitting} 
                    className="px-6 py-2.5 bg-blue-900 text-white rounded-lg text-sm font-bold hover:bg-blue-800 disabled:opacity-50 transition-colors shadow-sm cursor-pointer"
                  >
                    {isSubmitting ? "Saving Product..." : (editingProduct ? "Save Changes" : "Create Product")}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* QUICK ADJUST VALUES MODAL */}
      {quickAdjustProduct && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col my-auto animate-in fade-in zoom-in-95">
            <div className="flex justify-between items-center px-6 py-4 bg-amber-500 text-white">
              <div>
                <h3 className="font-bold text-base">Quick Adjust Price & Stock</h3>
                <p className="text-xs text-amber-100">{quickAdjustProduct.name}</p>
              </div>
              <button 
                onClick={() => setQuickAdjustProduct(null)}
                className="p-1 hover:bg-amber-600 rounded-full transition-colors text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickAdjust} className="p-6 space-y-4">
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-blue-900">
                Directly adjust market prices or conduct physical stock reconciliation without modifying product metadata.
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Retail Selling Price (₦)</label>
                  <input 
                    required 
                    type="number" 
                    step="any"
                    value={quickAdjustForm.sellingPrice} 
                    onChange={e => setQuickAdjustForm({...quickAdjustForm, sellingPrice: Number(e.target.value)})}
                    className="w-full p-2.5 border border-gray-200 rounded-lg text-sm font-bold text-blue-900 outline-none focus:ring-2 focus:ring-blue-500" 
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Wholesale Price (₦)</label>
                  <input 
                    required 
                    type="number" 
                    step="any"
                    value={quickAdjustForm.wholesalePrice} 
                    onChange={e => setQuickAdjustForm({...quickAdjustForm, wholesalePrice: Number(e.target.value)})}
                    className="w-full p-2.5 border border-gray-200 rounded-lg text-sm font-bold text-amber-800 outline-none focus:ring-2 focus:ring-blue-500" 
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Cost / Buying Price (₦)</label>
                  <input 
                    required 
                    type="number" 
                    step="any"
                    value={quickAdjustForm.buyingPrice} 
                    onChange={e => setQuickAdjustForm({...quickAdjustForm, buyingPrice: Number(e.target.value)})}
                    className="w-full p-2.5 border border-gray-200 rounded-lg text-sm font-medium text-gray-800 outline-none focus:ring-2 focus:ring-blue-500" 
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Current Stock ({quickAdjustProduct.unit})
                  </label>
                  <input 
                    required 
                    type="number" 
                    step="any"
                    value={quickAdjustForm.currentStock} 
                    onChange={e => setQuickAdjustForm({...quickAdjustForm, currentStock: Number(e.target.value)})}
                    className="w-full p-2.5 border border-amber-300 bg-amber-50/50 rounded-lg text-sm font-bold text-gray-900 outline-none focus:ring-2 focus:ring-amber-500" 
                  />
                </div>
              </div>

              {/* Optional Reason for Audit Log */}
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Reason for Adjustment <span className="text-gray-400 font-normal">(Recorded in System Audit Log)</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g., Weekly PMS depot tariff increase; Morning tank dip calibration; Physical cylinder audit"
                  value={quickAdjustForm.reason}
                  onChange={e => setQuickAdjustForm({...quickAdjustForm, reason: e.target.value})}
                  className="w-full p-2.5 border border-gray-200 rounded-lg text-xs outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl text-xs flex justify-between border border-gray-100">
                <span className="text-gray-500">Calculated Stock Value (Cost):</span>
                <span className="font-bold text-emerald-700">
                  {formatCurrency(quickAdjustForm.currentStock * quickAdjustForm.buyingPrice)}
                </span>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
                <button 
                  type="button" 
                  onClick={() => setQuickAdjustProduct(null)} 
                  className="px-4 py-2 border border-gray-200 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  disabled={isSubmitting} 
                  className="px-5 py-2 bg-amber-500 text-white rounded-lg text-xs font-bold hover:bg-amber-600 transition-colors"
                >
                  {isSubmitting ? "Updating..." : "Update Values"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {deleteConfirmProduct && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-gray-900">Delete Product?</h3>
            <p className="text-sm text-gray-500 mt-1">
              Are you sure you want to remove <span className="font-semibold text-gray-800">"{deleteConfirmProduct.name}"</span> from the inventory? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3 mt-6">
              <button 
                type="button"
                onClick={() => setDeleteConfirmProduct(null)}
                className="px-4 py-2 border border-gray-200 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button 
                type="button"
                onClick={handleDeleteProduct}
                disabled={isSubmitting}
                className="px-5 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 disabled:opacity-50 transition-colors"
              >
                {isSubmitting ? "Deleting..." : "Yes, Delete Product"}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* CSV INVENTORY IMPORT MODAL */}
      <CsvInventoryImportModal
        isOpen={isCsvImportOpen}
        onClose={() => setIsCsvImportOpen(false)}
        existingProducts={products}
        onImportComplete={async (summary) => {
          await refreshData();
          showToast(`Imported ${summary.added} new product(s) and updated ${summary.updated} product(s).`);
        }}
      />
    </div>
  );
}
