import React, { useContext, useState, useMemo } from "react";
import { DataContext } from "../components/Layout";
import { useAuth } from "../store/AuthContext";
import { formatCurrency, formatDate } from "../lib/utils";
import Receipt from "../components/Receipt";
import InvoiceModal from "../components/InvoiceModal";
import WaybillModal from "../components/WaybillModal";
import VoidInvoiceModal from "../components/VoidInvoiceModal";
import AuditLogViewer from "../components/AuditLogViewer";
import { Sale } from "../types";
import { 
  FileSpreadsheet, 
  FileText, 
  Printer, 
  Filter, 
  Calendar, 
  TrendingUp, 
  DollarSign, 
  Package, 
  ShoppingCart, 
  Truck, 
  Users, 
  CheckCircle2,
  BarChart3,
  Search,
  Download,
  Eye,
  ShieldCheck,
  AlertOctagon,
  Trash2
} from "lucide-react";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

type ReportTab = "sales" | "inventory" | "purchases" | "profit" | "customers" | "audit";
type DateFilter = "today" | "yesterday" | "this_week" | "this_month" | "all" | "custom";

export default function Reports() {
  const { sales = [], products = [], purchases = [], customers = [], settings = {}, auditLogs = [], refreshData } = useContext(DataContext);
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [activeTab, setActiveTab] = useState<ReportTab>("sales");
  const [dateFilter, setDateFilter] = useState<DateFilter>("this_month");
  const [customStartDate, setCustomStartDate] = useState("");
  const [customEndDate, setCustomEndDate] = useState("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedSaleForReceipt, setSelectedSaleForReceipt] = useState<Sale | null>(null);
  const [selectedSaleForInvoice, setSelectedSaleForInvoice] = useState<Sale | null>(null);
  const [selectedSaleForWaybill, setSelectedSaleForWaybill] = useState<Sale | null>(null);
  const [voidSaleTarget, setVoidSaleTarget] = useState<Sale | null>(null);
  const [salesSearchQuery, setSalesSearchQuery] = useState("");

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Helper date range check
  const isWithinDateRange = (dateStr: string) => {
    if (!dateStr) return false;
    const date = new Date(dateStr);
    const now = new Date();

    if (dateFilter === "all") return true;

    if (dateFilter === "today") {
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      return date >= todayStart;
    }

    if (dateFilter === "yesterday") {
      const yesterdayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      return date >= yesterdayStart && date < todayStart;
    }

    if (dateFilter === "this_week") {
      const day = now.getDay();
      const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Monday
      const weekStart = new Date(now.setDate(diff));
      weekStart.setHours(0, 0, 0, 0);
      return date >= weekStart;
    }

    if (dateFilter === "this_month") {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      return date >= monthStart;
    }

    if (dateFilter === "custom") {
      if (customStartDate && new Date(dateStr) < new Date(customStartDate)) return false;
      if (customEndDate) {
        const end = new Date(customEndDate);
        end.setHours(23, 59, 59, 999);
        if (new Date(dateStr) > end) return false;
      }
      return true;
    }

    return true;
  };

  // Filtered data based on selected period
  const filteredSales = useMemo(() => {
    return sales.filter((s: any) => isWithinDateRange(s.date));
  }, [sales, dateFilter, customStartDate, customEndDate]);

  const searchedSales = useMemo(() => {
    if (!salesSearchQuery.trim()) return filteredSales;
    const q = salesSearchQuery.toLowerCase().trim();
    return filteredSales.filter((s: any) =>
      s.invoiceNumber?.toLowerCase().includes(q) ||
      s.customerName?.toLowerCase().includes(q) ||
      s.staffName?.toLowerCase().includes(q) ||
      s.paymentMethod?.toLowerCase().includes(q) ||
      (s.vehicleNumber && s.vehicleNumber.toLowerCase().includes(q))
    );
  }, [filteredSales, salesSearchQuery]);

  const filteredPurchases = useMemo(() => {
    return purchases.filter((p: any) => isWithinDateRange(p.date));
  }, [purchases, dateFilter, customStartDate, customEndDate]);

  // Overall Financial Calculations
  const totalSalesRevenue = filteredSales.reduce((sum: number, s: any) => sum + (s.totalAmount || 0), 0);
  const totalSalesSubtotal = filteredSales.reduce((sum: number, s: any) => sum + (s.subtotal || 0), 0);
  const totalDiscountsGiven = filteredSales.reduce((sum: number, s: any) => sum + (s.discount || 0), 0);
  const totalPurchaseCost = filteredPurchases.reduce((sum: number, p: any) => sum + (p.totalCost || 0), 0);

  // COGS Calculation based on sold items buying price
  const totalCOGS = useMemo(() => {
    let cogs = 0;
    filteredSales.forEach((sale: any) => {
      (sale.items || []).forEach((item: any) => {
        const product = products.find((p: any) => p.id === item.productId);
        const costPrice = item.costPrice || (product ? product.buyingPrice : 0) || 0;
        cogs += costPrice * (item.quantity || 0);
      });
    });
    return cogs;
  }, [filteredSales, products]);

  const estimatedGrossProfit = totalSalesRevenue - totalCOGS;
  const grossProfitMargin = totalSalesRevenue > 0 ? ((estimatedGrossProfit / totalSalesRevenue) * 100) : 0;

  // Inventory Valuations
  const totalInventoryCostValue = products.reduce((sum: number, p: any) => sum + ((p.currentStock || 0) * (p.buyingPrice || 0)), 0);
  const totalInventoryRetailValue = products.reduce((sum: number, p: any) => sum + ((p.currentStock || 0) * (p.sellingPrice || 0)), 0);

  // Date range label for export headers
  const dateRangeLabel = useMemo(() => {
    switch (dateFilter) {
      case "today": return "Today";
      case "yesterday": return "Yesterday";
      case "this_week": return "This Week";
      case "this_month": return "This Month";
      case "all": return "All Time";
      case "custom": return `Custom Range (${customStartDate || "Start"} to ${customEndDate || "End"})`;
      default: return "Selected Period";
    }
  }, [dateFilter, customStartDate, customEndDate]);

  // ================= EXCEL EXPORT HANDLER =================
  const handleDownloadExcel = () => {
    try {
      const wb = XLSX.utils.book_new();
      const businessName = settings.businessName || "Croissance Oil and Gas Ltd";
      const timestamp = new Date().toLocaleString("en-GB");

      // 1. Sales Sheet
      if (activeTab === "sales" || activeTab === "profit") {
        const salesRows = filteredSales.map((s: any) => ({
          "Invoice No": s.invoiceNumber,
          "Date & Time": formatDate(s.date),
          "Customer": s.customerName || "Walk-in",
          "Attendant": s.staffName || "Staff",
          "Payment Method": s.paymentMethod,
          "Subtotal (NGN)": s.subtotal || s.totalAmount,
          "Discount (NGN)": s.discount || 0,
          "Total Amount (NGN)": s.totalAmount,
          "Items Description": (s.items || []).map((i: any) => `${i.productName} (${i.quantity})`).join("; ")
        }));

        const wsSales = XLSX.utils.json_to_sheet(salesRows);
        XLSX.utils.book_append_sheet(wb, wsSales, "Sales Transactions");
      }

      // 2. Inventory Sheet
      if (activeTab === "inventory" || activeTab === "profit") {
        const inventoryRows = products.map((p: any) => ({
          "Product Name": p.name,
          "Category": p.category,
          "Unit": p.unit,
          "Buying Price (NGN)": p.buyingPrice,
          "Retail Selling Price (NGN)": p.sellingPrice,
          "Wholesale Price (NGN)": p.wholesalePrice,
          "Current Stock": p.currentStock,
          "Min Stock Alert": p.minStock,
          "Total Value at Cost (NGN)": p.currentStock * (p.buyingPrice || 0),
          "Total Value at Retail (NGN)": p.currentStock * (p.sellingPrice || 0),
          "Stock Status": p.currentStock <= p.minStock ? "LOW STOCK" : "Healthy"
        }));

        const wsInventory = XLSX.utils.json_to_sheet(inventoryRows);
        XLSX.utils.book_append_sheet(wb, wsInventory, "Inventory Valuation");
      }

      // 3. Purchases Sheet
      if (activeTab === "purchases") {
        const purchaseRows = filteredPurchases.map((p: any) => ({
          "Purchase ID": p.id,
          "Date": formatDate(p.date),
          "Supplier": p.supplierName,
          "Product": p.productName,
          "Quantity": p.quantity,
          "Unit Cost (NGN)": p.unitCost,
          "Total Cost (NGN)": p.totalCost,
          "Recorded By": p.recordedBy || "Admin"
        }));

        const wsPurchases = XLSX.utils.json_to_sheet(purchaseRows);
        XLSX.utils.book_append_sheet(wb, wsPurchases, "Stock Receipts");
      }

      // 4. Profit & Loss Sheet
      if (activeTab === "profit") {
        const pnlRows = [
          { "Metric": "Business Name", "Value": businessName },
          { "Metric": "Report Period", "Value": dateRangeLabel },
          { "Metric": "Generated At", "Value": timestamp },
          { "Metric": "Total Sales Revenue", "Value": totalSalesRevenue },
          { "Metric": "Cost of Goods Sold (COGS)", "Value": totalCOGS },
          { "Metric": "Total Discounts Given", "Value": totalDiscountsGiven },
          { "Metric": "Estimated Gross Profit", "Value": estimatedGrossProfit },
          { "Metric": "Gross Profit Margin (%)", "Value": `${grossProfitMargin.toFixed(2)}%` },
          { "Metric": "Total Purchases During Period", "Value": totalPurchaseCost },
          { "Metric": "Current Total Inventory Value (Cost)", "Value": totalInventoryCostValue }
        ];
        const wsPnl = XLSX.utils.json_to_sheet(pnlRows);
        XLSX.utils.book_append_sheet(wb, wsPnl, "Profit Summary");
      }

      // 5. Customers Sheet
      if (activeTab === "customers") {
        const customerRows = customers.map((c: any) => {
          const custSales = sales.filter((s: any) => s.customerId === c.id);
          const custTotal = custSales.reduce((sum: number, s: any) => sum + (s.totalAmount || 0), 0);
          return {
            "Customer Name": c.fullName,
            "Phone": c.phone || "N/A",
            "Type": c.type,
            "Business Name": c.businessName || "N/A",
            "Transactions Count": custSales.length,
            "Total Purchases (NGN)": custTotal
          };
        });

        const wsCustomers = XLSX.utils.json_to_sheet(customerRows);
        XLSX.utils.book_append_sheet(wb, wsCustomers, "Customer Activity");
      }

      // 6. Audit Trail Sheet
      if (activeTab === "audit") {
        const auditRows = (auditLogs || [])
          .filter((l: any) => isWithinDateRange(l.timestamp))
          .map((l: any) => ({
            "Log ID": l.id,
            "Date & Time": formatDate(l.timestamp),
            "Severity": l.severity,
            "Category": l.category,
            "Action": l.action,
            "Actor Name": l.actorName,
            "Actor Role": l.actorRole,
            "Terminal Station": l.terminalStation || "Admin Office",
            "IP Address": l.ipAddress || "127.0.0.1",
            "Target Entity": l.targetEntityName,
            "Target ID": l.targetEntityId,
            "Description": l.description,
            "Compliance Reason": l.reason || "N/A",
            "Impact & Diff Summary": l.diffSummary || "N/A"
          }));

        const wsAudit = XLSX.utils.json_to_sheet(auditRows);
        XLSX.utils.book_append_sheet(wb, wsAudit, "Audit & Compliance Trail");
      }

      const fileName = `Croissance_${activeTab.toUpperCase()}_Report_${new Date().toISOString().slice(0, 10)}.xlsx`;
      XLSX.writeFile(wb, fileName);
      showToast(`Excel report downloaded: ${fileName}`);
    } catch (err: any) {
      console.error(err);
      alert("Failed to export Excel report: " + err.message);
    }
  };

  // ================= PDF EXPORT HANDLER =================
  const handleDownloadPDF = () => {
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const businessName = settings.businessName || "CROISSANCE OIL AND GAS LTD";
      const rcNumber = settings.rcNumber || "1292088";
      const stationAddress = settings.stationAddress || "Abule Pan Bus Stop, Ibeju Lekki, OPC Junction, Lagos, Nigeria.";
      const phoneNumbers = settings.phoneNumbers || "08131307891, 08164782722";

      // 1. Header Banner
      doc.setFillColor(30, 58, 138); // Dark Navy Blue (#1e3a8a)
      doc.rect(0, 0, 210, 36, "F");

      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(15);
      doc.text(businessName.toUpperCase(), 14, 12);

      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.text(`RC: ${rcNumber} | Phone: ${phoneNumbers}`, 14, 18);
      doc.text(stationAddress, 14, 23);

      doc.setTextColor(245, 158, 11); // Amber-500
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9);
      doc.text(`OFFICIAL ${activeTab.toUpperCase()} REPORT - ${dateRangeLabel.toUpperCase()}`, 14, 30);

      doc.setTextColor(80, 80, 80);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.text(`Generated: ${new Date().toLocaleString("en-GB")}`, 14, 42);

      // 2. Tab-specific Tables and Summaries
      if (activeTab === "sales") {
        // Summary KPIs
        autoTable(doc, {
          startY: 46,
          head: [["Total Sales Revenue", "Transactions Count", "Discounts Granted", "Net Subtotal"]],
          body: [[
            formatCurrency(totalSalesRevenue),
            `${filteredSales.length} Orders`,
            formatCurrency(totalDiscountsGiven),
            formatCurrency(totalSalesSubtotal)
          ]],
          theme: "grid",
          headStyles: { fillColor: [243, 244, 246], textColor: [55, 65, 81], fontSize: 8, fontStyle: "bold" },
          styles: { fontSize: 8.5, textColor: [30, 58, 138], fontStyle: "bold", halign: "center" }
        });

        // Transactions Table
        const tableRows = filteredSales.map((s: any) => [
          s.invoiceNumber,
          formatDate(s.date),
          s.customerName || "Walk-in",
          s.paymentMethod,
          formatCurrency(s.subtotal || s.totalAmount),
          formatCurrency(s.discount || 0),
          formatCurrency(s.totalAmount)
        ]);

        autoTable(doc, {
          startY: (doc as any).lastAutoTable.finalY + 6,
          head: [["Invoice #", "Date", "Customer", "Method", "Subtotal", "Discount", "Total Amount"]],
          body: tableRows,
          theme: "striped",
          headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontSize: 8 },
          styles: { fontSize: 7.5, cellPadding: 2 },
          columnStyles: {
            4: { halign: "right" },
            5: { halign: "right" },
            6: { halign: "right", fontStyle: "bold" }
          }
        });
      } else if (activeTab === "inventory") {
        autoTable(doc, {
          startY: 46,
          head: [["Total Inventory Items", "Stock Value (Cost)", "Stock Value (Retail)", "Low Stock Alerts"]],
          body: [[
            `${products.length} Products`,
            formatCurrency(totalInventoryCostValue),
            formatCurrency(totalInventoryRetailValue),
            `${products.filter((p: any) => p.currentStock <= p.minStock).length} Items`
          ]],
          theme: "grid",
          headStyles: { fillColor: [243, 244, 246], textColor: [55, 65, 81], fontSize: 8, fontStyle: "bold" },
          styles: { fontSize: 8.5, textColor: [16, 185, 129], fontStyle: "bold", halign: "center" }
        });

        const tableRows = products.map((p: any) => [
          p.name,
          p.category,
          `${p.currentStock} ${p.unit}`,
          formatCurrency(p.buyingPrice || 0),
          formatCurrency(p.sellingPrice || 0),
          formatCurrency((p.currentStock || 0) * (p.buyingPrice || 0)),
          p.currentStock <= p.minStock ? "LOW" : "OK"
        ]);

        autoTable(doc, {
          startY: (doc as any).lastAutoTable.finalY + 6,
          head: [["Product Name", "Category", "Current Stock", "Cost Price", "Retail Price", "Total Stock Value (Cost)", "Status"]],
          body: tableRows,
          theme: "striped",
          headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontSize: 8 },
          styles: { fontSize: 7.5, cellPadding: 2 },
          columnStyles: {
            3: { halign: "right" },
            4: { halign: "right" },
            5: { halign: "right", fontStyle: "bold" },
            6: { halign: "center" }
          }
        });
      } else if (activeTab === "purchases") {
        autoTable(doc, {
          startY: 46,
          head: [["Total Purchases Cost", "Receipt Entries", "Reporting Period"]],
          body: [[
            formatCurrency(totalPurchaseCost),
            `${filteredPurchases.length} Receipts`,
            dateRangeLabel
          ]],
          theme: "grid",
          headStyles: { fillColor: [243, 244, 246], textColor: [55, 65, 81], fontSize: 8, fontStyle: "bold" },
          styles: { fontSize: 8.5, textColor: [220, 38, 38], fontStyle: "bold", halign: "center" }
        });

        const tableRows = filteredPurchases.map((p: any) => [
          p.id,
          formatDate(p.date),
          p.supplierName,
          p.productName,
          `${p.quantity}`,
          formatCurrency(p.unitCost),
          formatCurrency(p.totalCost)
        ]);

        autoTable(doc, {
          startY: (doc as any).lastAutoTable.finalY + 6,
          head: [["ID", "Date", "Supplier", "Product", "Quantity", "Unit Cost", "Total Cost"]],
          body: tableRows,
          theme: "striped",
          headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontSize: 8 },
          styles: { fontSize: 7.5, cellPadding: 2 },
          columnStyles: {
            5: { halign: "right" },
            6: { halign: "right", fontStyle: "bold" }
          }
        });
      } else if (activeTab === "profit") {
        // Profit breakdown summary
        const pnlRows = [
          ["Total Sales Revenue (Gross Inflow)", formatCurrency(totalSalesRevenue)],
          ["Cost of Goods Sold (COGS)", `-${formatCurrency(totalCOGS)}`],
          ["Discounts Subsidized", `-${formatCurrency(totalDiscountsGiven)}`],
          ["ESTIMATED GROSS PROFIT", formatCurrency(estimatedGrossProfit)],
          ["Gross Profit Margin (%)", `${grossProfitMargin.toFixed(2)}%`],
          ["Inventory Valuation at Cost", formatCurrency(totalInventoryCostValue)],
          ["Total Stock Purchases in Period", formatCurrency(totalPurchaseCost)]
        ];

        autoTable(doc, {
          startY: 46,
          head: [["Financial Metric", "Amount (NGN)"]],
          body: pnlRows,
          theme: "grid",
          headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontSize: 9 },
          styles: { fontSize: 8.5, cellPadding: 3 },
          columnStyles: { 1: { halign: "right", fontStyle: "bold" } }
        });
      } else if (activeTab === "customers") {
        const tableRows = customers.map((c: any) => {
          const custSales = sales.filter((s: any) => s.customerId === c.id);
          const custTotal = custSales.reduce((sum: number, s: any) => sum + (s.totalAmount || 0), 0);
          return [
            c.fullName,
            c.phone || "N/A",
            c.type,
            `${custSales.length}`,
            formatCurrency(custTotal)
          ];
        });

        autoTable(doc, {
          startY: 46,
          head: [["Customer Name", "Phone", "Customer Type", "Total Orders", "Cumulative Purchases"]],
          body: tableRows,
          theme: "striped",
          headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontSize: 8 },
          styles: { fontSize: 7.5, cellPadding: 2.5 },
          columnStyles: { 4: { halign: "right", fontStyle: "bold" } }
        });
      } else if (activeTab === "audit") {
        const auditRows = (auditLogs || [])
          .filter((l: any) => isWithinDateRange(l.timestamp))
          .map((l: any) => [
            new Date(l.timestamp).toLocaleDateString("en-GB") + " " + new Date(l.timestamp).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }),
            l.severity,
            l.action.replace(/_/g, " "),
            `${l.actorName} (${l.actorRole})`,
            l.targetEntityName,
            l.description + (l.reason ? ` [Reason: ${l.reason}]` : ""),
            l.diffSummary || "—"
          ]);

        autoTable(doc, {
          startY: 46,
          head: [["Timestamp", "Severity", "Action", "Actor", "Target", "Description", "Diff Summary"]],
          body: auditRows,
          theme: "striped",
          headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontSize: 7.5, fontStyle: "bold" },
          styles: { fontSize: 6.5, cellPadding: 2 },
          columnStyles: {
            0: { cellWidth: 26 },
            1: { cellWidth: 16 },
            2: { cellWidth: 24 },
            3: { cellWidth: 24 },
            4: { cellWidth: 22 },
            5: { cellWidth: 46 },
            6: { cellWidth: 32 }
          }
        });
      }

      // Footer
      const pageCount = (doc as any).internal.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(7.5);
        doc.setTextColor(150, 150, 150);
        doc.text(
          `Croissance Oil and Gas Ltd - Page ${i} of ${pageCount} | Automated Management Report`,
          14,
          290
        );
      }

      const fileName = `Croissance_${activeTab.toUpperCase()}_Report_${new Date().toISOString().slice(0, 10)}.pdf`;
      doc.save(fileName);
      showToast(`PDF report downloaded: ${fileName}`);
    } catch (err: any) {
      console.error(err);
      alert("Failed to export PDF report: " + err.message);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-blue-900 text-white px-5 py-3 rounded-lg shadow-xl flex items-center gap-3 border border-blue-700 animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0" />
          <span className="font-medium text-sm">{toastMessage}</span>
        </div>
      )}

      {/* Header & Export Actions */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-blue-900">Reports & Analytics</h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Generate, analyze, and export business performance data in Excel (.xlsx) and PDF format.
          </p>
        </div>

        {/* Download Buttons Toolbar */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleDownloadExcel}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold text-xs transition-colors shadow-xs cursor-pointer"
            title="Download formatted Excel Spreadsheet (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Download Excel (.xlsx)</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-2 px-4 py-2.5 bg-red-700 hover:bg-red-800 text-white rounded-lg font-semibold text-xs transition-colors shadow-xs cursor-pointer"
            title="Download printable PDF Report (.pdf)"
          >
            <FileText className="w-4 h-4" />
            <span>Download PDF (.pdf)</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-3.5 py-2.5 border border-gray-300 bg-white hover:bg-gray-50 text-gray-700 rounded-lg font-semibold text-xs transition-colors cursor-pointer"
            title="Print Report"
          >
            <Printer className="w-4 h-4" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Report Type Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-gray-100 rounded-lg">
          {[
            { key: "sales", label: "Sales Report", icon: ShoppingCart },
            { key: "inventory", label: "Inventory Valuation", icon: Package },
            { key: "purchases", label: "Purchases Report", icon: Truck },
            { key: "profit", label: "Profit & Margins", icon: TrendingUp },
            { key: "customers", label: "Customer Ledger", icon: Users },
            { key: "audit", label: "Audit & Compliance Log", icon: ShieldCheck },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as ReportTab)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  isActive 
                    ? "bg-blue-900 text-white shadow-xs" 
                    : "text-gray-600 hover:text-gray-900 hover:bg-white/60"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.key === "audit" && (auditLogs || []).length > 0 && (
                  <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                    isActive ? "bg-amber-400 text-blue-950" : "bg-blue-100 text-blue-900"
                  }`}>
                    {(auditLogs || []).length}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Date Filter Dropdown and Custom Pickers */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-gray-500 font-medium">
            <Calendar className="w-3.5 h-3.5" />
            <span>Timeframe:</span>
          </div>

          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value as DateFilter)}
            className="bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-xs font-semibold text-gray-700 outline-none focus:border-blue-500"
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="this_week">This Week</option>
            <option value="this_month">This Month</option>
            <option value="all">All Time</option>
            <option value="custom">Custom Date Range</option>
          </select>

          {dateFilter === "custom" && (
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={customStartDate}
                onChange={e => setCustomStartDate(e.target.value)}
                className="border border-gray-200 rounded-lg px-2.5 py-1 text-xs outline-none"
                title="Start Date"
              />
              <span className="text-xs text-gray-400">to</span>
              <input
                type="date"
                value={customEndDate}
                onChange={e => setCustomEndDate(e.target.value)}
                className="border border-gray-200 rounded-lg px-2.5 py-1 text-xs outline-none"
                title="End Date"
              />
            </div>
          )}
        </div>
      </div>

      {/* Top Financial Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Total Sales ({dateRangeLabel})</p>
          <p className="text-2xl font-bold text-blue-900 mt-1">{formatCurrency(totalSalesRevenue)}</p>
          <p className="text-xs text-gray-400 mt-0.5">{filteredSales.length} recorded sales orders</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Purchases & Inflow</p>
          <p className="text-2xl font-bold text-red-600 mt-1">{formatCurrency(totalPurchaseCost)}</p>
          <p className="text-xs text-gray-400 mt-0.5">{filteredPurchases.length} stock receipts</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm bg-gradient-to-br from-amber-50/60 to-white">
          <p className="text-xs font-semibold text-amber-900 uppercase tracking-wider">Estimated Gross Profit</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">{formatCurrency(estimatedGrossProfit)}</p>
          <p className="text-xs text-amber-700/80 mt-0.5">Est. Margin: {grossProfitMargin.toFixed(1)}%</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-gray-100 shadow-sm">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Current Inventory Value (Cost)</p>
          <p className="text-2xl font-bold text-emerald-700 mt-1">{formatCurrency(totalInventoryCostValue)}</p>
          <p className="text-xs text-gray-400 mt-0.5">Potential Retail: {formatCurrency(totalInventoryRetailValue)}</p>
        </div>
      </div>

      {/* Dynamic Report Content based on Active Tab */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {/* Table Header Banner */}
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/70">
          <div>
            <h2 className="text-base font-bold text-gray-800 capitalize">
              {activeTab === "sales" && "Sales Transactions & Invoices"}
              {activeTab === "inventory" && "Stock Valuation & Current Inventory Status"}
              {activeTab === "purchases" && "Purchases & Stock Received Log"}
              {activeTab === "profit" && "Gross Profit Margin & Financial Breakdown"}
              {activeTab === "customers" && "Customer Purchase Volume & History"}
              {activeTab === "audit" && "System Audit & Compliance Activity Trail"}
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Filtered for <span className="font-semibold text-blue-900">{dateRangeLabel}</span>
            </p>
          </div>

          <div className="text-xs font-medium text-gray-500">
            {activeTab === "sales" && `${filteredSales.length} Transactions`}
            {activeTab === "inventory" && `${products.length} Products`}
            {activeTab === "purchases" && `${filteredPurchases.length} Records`}
            {activeTab === "customers" && `${customers.length} Customers`}
            {activeTab === "audit" && `${(auditLogs || []).filter((l: any) => isWithinDateRange(l.timestamp)).length} Audited Events`}
          </div>
        </div>

        {/* TAB 1: SALES REPORT TABLE */}
        {activeTab === "sales" && (
          <div>
            {/* Quick Search & Reprint Bar */}
            <div className="p-3 bg-blue-50/40 border-b border-gray-100 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Quick search or reprint by Invoice #, Customer, Attendant..."
                  value={salesSearchQuery}
                  onChange={(e) => setSalesSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              {salesSearchQuery && (
                <button
                  onClick={() => setSalesSearchQuery("")}
                  className="text-xs text-blue-700 hover:underline font-medium self-end sm:self-auto cursor-pointer"
                >
                  Clear search ({searchedSales.length} found)
                </button>
              )}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm whitespace-nowrap">
                <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
                  <tr>
                    <th className="px-5 py-3">Date</th>
                    <th className="px-5 py-3">Invoice No</th>
                    <th className="px-5 py-3">Customer</th>
                    <th className="px-5 py-3">Cashier / Staff</th>
                    <th className="px-5 py-3">Payment</th>
                    <th className="px-5 py-3 text-right">Subtotal</th>
                    <th className="px-5 py-3 text-right">Discount</th>
                    <th className="px-5 py-3 text-right">Total Amount</th>
                    <th className="px-5 py-3 text-center">Reprint &amp; Documents</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {[...searchedSales].reverse().map((sale: any) => (
                    <tr key={sale.id} className="hover:bg-blue-50/30 transition-colors">
                      <td className="px-5 py-3.5 text-xs text-gray-600">{formatDate(sale.date)}</td>
                      <td className="px-5 py-3.5 font-bold text-blue-900">
                        <button
                          onClick={() => setSelectedSaleForReceipt(sale)}
                          className="hover:underline flex items-center gap-1 cursor-pointer text-left"
                          title="Click to view/reprint receipt"
                        >
                          <Printer className="w-3.5 h-3.5 text-blue-600" />
                          <span>{sale.invoiceNumber}</span>
                        </button>
                      </td>
                      <td className="px-5 py-3.5 text-gray-800 font-medium">{sale.customerName || "Walk-in Customer"}</td>
                      <td className="px-5 py-3.5 text-xs text-gray-500">{sale.staffName || "Attendant"}</td>
                      <td className="px-5 py-3.5">
                        <span className="px-2 py-0.5 rounded text-xs font-semibold bg-gray-100 text-gray-800">
                          {sale.paymentMethod}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right font-medium text-gray-600">
                        {formatCurrency(sale.subtotal || sale.totalAmount)}
                      </td>
                      <td className="px-5 py-3.5 text-right text-red-600 text-xs">
                        {sale.discount ? `-${formatCurrency(sale.discount)}` : "-"}
                      </td>
                      <td className="px-5 py-3.5 text-right font-bold text-blue-950">
                        {formatCurrency(sale.totalAmount)}
                      </td>
                      <td className="px-5 py-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* 1. Reprint Receipt button */}
                          <button
                            type="button"
                            onClick={() => setSelectedSaleForReceipt(sale)}
                            className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-900 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                            title="Reprint POS thermal receipt"
                          >
                            <Printer className="w-3.5 h-3.5 text-blue-600" />
                            <span>Reprint</span>
                          </button>

                          {/* 2. Download / Print Invoice */}
                          <button
                            type="button"
                            onClick={() => setSelectedSaleForInvoice(sale)}
                            className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                            title="View / Download A4 PDF Invoice"
                          >
                            <FileText className="w-3.5 h-3.5 text-amber-600" />
                            <span>Invoice</span>
                          </button>

                          {/* 3. Download / Print Waybill */}
                          <button
                            type="button"
                            onClick={() => setSelectedSaleForWaybill(sale)}
                            className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                            title="View / Download A4 PDF Waybill"
                          >
                            <Truck className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Waybill</span>
                          </button>

                          {/* 4. Admin Only: Void / Delete Invoice */}
                          {isAdmin && (
                            <button
                              type="button"
                              onClick={() => setVoidSaleTarget(sale)}
                              className="px-2.5 py-1 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                              title="Administrative action: Void and delete invoice with permanent audit logging"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-red-600" />
                              <span>Void</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {searchedSales.length === 0 && (
                    <tr>
                      <td colSpan={9} className="px-6 py-12 text-center text-gray-400">
                        No sales found matching your criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: INVENTORY REPORT TABLE */}
        {activeTab === "inventory" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
                <tr>
                  <th className="px-5 py-3">Product</th>
                  <th className="px-5 py-3">Category</th>
                  <th className="px-5 py-3 text-right">Buying Price</th>
                  <th className="px-5 py-3 text-right">Retail Price</th>
                  <th className="px-5 py-3 text-right">Wholesale Price</th>
                  <th className="px-5 py-3 text-right">Current Stock</th>
                  <th className="px-5 py-3 text-right">Total Value (Cost)</th>
                  <th className="px-5 py-3 text-right">Total Value (Retail)</th>
                  <th className="px-5 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {products.map((p: any) => {
                  const isLow = p.currentStock <= p.minStock;
                  return (
                    <tr key={p.id} className="hover:bg-blue-50/30">
                      <td className="px-5 py-3.5 font-semibold text-gray-900">{p.name}</td>
                      <td className="px-5 py-3.5 text-xs text-gray-500">{p.category}</td>
                      <td className="px-5 py-3.5 text-right text-gray-600">{formatCurrency(p.buyingPrice || 0)}</td>
                      <td className="px-5 py-3.5 text-right font-semibold text-blue-900">{formatCurrency(p.sellingPrice || 0)}</td>
                      <td className="px-5 py-3.5 text-right text-amber-700">{formatCurrency(p.wholesalePrice || 0)}</td>
                      <td className="px-5 py-3.5 text-right font-bold">
                        {p.currentStock.toLocaleString()} {p.unit}
                      </td>
                      <td className="px-5 py-3.5 text-right font-bold text-emerald-700">
                        {formatCurrency((p.currentStock || 0) * (p.buyingPrice || 0))}
                      </td>
                      <td className="px-5 py-3.5 text-right text-gray-600">
                        {formatCurrency((p.currentStock || 0) * (p.sellingPrice || 0))}
                      </td>
                      <td className="px-5 py-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${isLow ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-800'}`}>
                          {isLow ? "Low Stock" : "Sufficient"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 3: PURCHASES REPORT TABLE */}
        {activeTab === "purchases" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
                <tr>
                  <th className="px-5 py-3">Purchase ID</th>
                  <th className="px-5 py-3">Date</th>
                  <th className="px-5 py-3">Supplier Name</th>
                  <th className="px-5 py-3">Product Name</th>
                  <th className="px-5 py-3 text-right">Quantity</th>
                  <th className="px-5 py-3 text-right">Unit Cost</th>
                  <th className="px-5 py-3 text-right">Total Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {[...filteredPurchases].reverse().map((pur: any) => (
                  <tr key={pur.id} className="hover:bg-blue-50/30">
                    <td className="px-5 py-3.5 font-semibold text-blue-700">{pur.id}</td>
                    <td className="px-5 py-3.5 text-xs text-gray-600">{formatDate(pur.date)}</td>
                    <td className="px-5 py-3.5 font-medium text-gray-800">{pur.supplierName}</td>
                    <td className="px-5 py-3.5 text-gray-900">{pur.productName}</td>
                    <td className="px-5 py-3.5 text-right font-bold text-green-700">+{pur.quantity}</td>
                    <td className="px-5 py-3.5 text-right text-gray-600">{formatCurrency(pur.unitCost)}</td>
                    <td className="px-5 py-3.5 text-right font-bold text-red-600">{formatCurrency(pur.totalCost)}</td>
                  </tr>
                ))}
                {filteredPurchases.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-400">
                      No purchases logged during this period.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 4: PROFIT & MARGINS BREAKDOWN */}
        {activeTab === "profit" && (
          <div className="p-6">
            <div className="max-w-2xl mx-auto bg-gray-50/80 rounded-xl p-6 border border-gray-200/80 space-y-4">
              <h3 className="font-bold text-gray-900 text-base pb-3 border-b border-gray-200">
                Income Statement Summary ({dateRangeLabel})
              </h3>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between items-center py-1">
                  <span className="text-gray-600">Total Sales Revenue (Gross Orders)</span>
                  <span className="font-bold text-gray-900">{formatCurrency(totalSalesRevenue)}</span>
                </div>

                <div className="flex justify-between items-center py-1 text-red-600">
                  <span>Less: Cost of Goods Sold (COGS based on Buying Prices)</span>
                  <span className="font-semibold">-{formatCurrency(totalCOGS)}</span>
                </div>

                <div className="flex justify-between items-center py-1 text-amber-700">
                  <span>Less: Total Discounts Given</span>
                  <span className="font-semibold">-{formatCurrency(totalDiscountsGiven)}</span>
                </div>

                <div className="pt-3 border-t border-gray-300 flex justify-between items-center text-base">
                  <span className="font-bold text-blue-900">Estimated Gross Profit</span>
                  <span className="font-extrabold text-xl text-emerald-700">{formatCurrency(estimatedGrossProfit)}</span>
                </div>

                <div className="flex justify-between items-center py-1 text-xs text-gray-500">
                  <span>Gross Profit Margin Rate</span>
                  <span className="font-bold text-gray-800">{grossProfitMargin.toFixed(2)}%</span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-200 text-xs text-gray-500 space-y-1">
                <p>• Estimated profit formula: Profit = Selling Price − Buying Price per unit sold, less discounts.</p>
                <p>• Click "Download PDF" or "Download Excel" above to generate this statement for audit or board presentations.</p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: CUSTOMER LEDGER */}
        {activeTab === "customers" && (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-gray-50 text-gray-600 text-xs uppercase font-semibold">
                <tr>
                  <th className="px-5 py-3">Customer Name</th>
                  <th className="px-5 py-3">Company / Fleet</th>
                  <th className="px-5 py-3">Customer Type</th>
                  <th className="px-5 py-3 text-right">Credit Limit</th>
                  <th className="px-5 py-3 text-right">Outstanding Debt</th>
                  <th className="px-5 py-3 text-right">Orders Count</th>
                  <th className="px-5 py-3 text-right">Total Purchases Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {customers.map((c: any) => {
                  const custSales = sales.filter((s: any) => s.customerId === c.id);
                  const custTotal = custSales.reduce((sum: number, s: any) => sum + (s.totalAmount || 0), 0);
                  const isWholesale = c.type === "Wholesale";
                  const limit = Number(c.creditLimit || 0);
                  const balance = Number(c.outstandingBalance || 0);

                  return (
                    <tr key={c.id} className="hover:bg-blue-50/30">
                      <td className="px-5 py-3.5 font-semibold text-gray-900">{c.fullName}</td>
                      <td className="px-5 py-3.5 text-xs text-purple-700 font-medium">
                        {c.businessName || "—"}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${c.type === 'Wholesale' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'}`}>
                          {c.type}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right font-medium text-gray-700">
                        {isWholesale ? formatCurrency(limit) : "—"}
                      </td>
                      <td className="px-5 py-3.5 text-right font-bold">
                        {isWholesale ? (
                          balance > 0 ? (
                            <span className="text-red-700 bg-red-50 px-2 py-0.5 rounded">
                              {formatCurrency(balance)}
                            </span>
                          ) : (
                            <span className="text-emerald-700">₦0.00</span>
                          )
                        ) : "—"}
                      </td>
                      <td className="px-5 py-3.5 text-right font-medium text-gray-700">{custSales.length}</td>
                      <td className="px-5 py-3.5 text-right font-bold text-blue-900">{formatCurrency(custTotal)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 6: AUDIT & COMPLIANCE LOG */}
        {activeTab === "audit" && (
          <AuditLogViewer
            auditLogs={auditLogs}
            dateRangeLabel={dateRangeLabel}
            isWithinDateRange={isWithinDateRange}
          />
        )}
      </div>

      {/* Reprint Receipt Modal */}
      {selectedSaleForReceipt && (
        <Receipt
          sale={selectedSaleForReceipt}
          settings={settings}
          onClose={() => setSelectedSaleForReceipt(null)}
        />
      )}

      {/* Commercial Invoice Modal */}
      {selectedSaleForInvoice && (
        <InvoiceModal
          sale={selectedSaleForInvoice}
          settings={settings}
          onClose={() => setSelectedSaleForInvoice(null)}
        />
      )}

      {/* Waybill / Delivery Note Modal */}
      {selectedSaleForWaybill && (
        <WaybillModal
          sale={selectedSaleForWaybill}
          settings={settings}
          onClose={() => setSelectedSaleForWaybill(null)}
        />
      )}

      {/* Void Invoice Confirmation Modal */}
      {voidSaleTarget && (
        <VoidInvoiceModal
          sale={voidSaleTarget}
          onClose={() => setVoidSaleTarget(null)}
          onSuccess={async (deletedInvoiceNumber) => {
            setVoidSaleTarget(null);
            showToast(`Invoice ${deletedInvoiceNumber} was permanently voided and recorded in Audit Log.`);
            await refreshData();
          }}
        />
      )}
    </div>
  );
}
